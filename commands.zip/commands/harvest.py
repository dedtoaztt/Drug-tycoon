from discord.ext import commands
import database

class Harvest(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def harvest(self, ctx):
        conn = database.get_db()
        c = conn.cursor()
        c.execute("UPDATE users SET harvested = harvested + 1 WHERE user_id = ?", (ctx.author.id,))
        conn.commit()
        conn.close()
        await ctx.send(f"{ctx.author.mention} 🌾 You harvested 1 batch of OG Kush!")

def setup(bot):
    bot.add_cog(Harvest(bot))
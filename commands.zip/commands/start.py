from discord.ext import commands
import database

class Start(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def start(self, ctx):
        conn = database.get_db()
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            cash INTEGER DEFAULT 100,
            strain TEXT DEFAULT 'OG Kush',
            harvested INTEGER DEFAULT 0
        )''')
        c.execute("INSERT OR IGNORE INTO users (user_id) VALUES (?)", (ctx.author.id,))
        conn.commit()
        conn.close()
        await ctx.send(f"{ctx.author.mention} 🌿 Welcome to Weed Hustle Tycoon!")

def setup(bot):
    bot.add_cog(Start(bot))
from discord.ext import commands

class Grow(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def grow(self, ctx):
        await ctx.send(f"{ctx.author.mention} 🌱 You planted some OG Kush! Come back in 1 minute to harvest.")

def setup(bot):
    bot.add_cog(Grow(bot))
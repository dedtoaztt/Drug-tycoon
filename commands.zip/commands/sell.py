from discord.ext import commands
import database

class Sell(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def sell(self, ctx):
        conn = database.get_db()
        c = conn.cursor()
        c.execute("SELECT harvested, cash FROM users WHERE user_id = ?", (ctx.author.id,))
        result = c.fetchone()

        if result and result[0] > 0:
            earnings = result[0] * 50
            new_cash = result[1] + earnings
            c.execute("UPDATE users SET cash = ?, harvested = 0 WHERE user_id = ?", (new_cash, ctx.author.id))
            conn.commit()
            await ctx.send(f"{ctx.author.mention} 💸 You sold {result[0]} batches and earned ${earnings}!")
        else:
            await ctx.send("🌱 You don't have any product to sell!")

        conn.close()

def setup(bot):
    bot.add_cog(Sell(bot))